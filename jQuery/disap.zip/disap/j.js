$('img').click(function(){$(this).animate({opacity:0});});

$('p').click(function(){$('img').animate({opacity:100});});
